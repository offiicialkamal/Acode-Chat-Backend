


class validator:
    # because of i always not need to verify the all field so ill define all function as global function 
    # each method should return an json object as response 
    # example {'status': True/False, 'message':'....'}
    
    def __init__(self):
        print('constructor called')
    
    def validate_first_name(name):
        pass
        
