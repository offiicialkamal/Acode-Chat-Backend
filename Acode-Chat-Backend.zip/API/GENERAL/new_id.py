#№№#############################
#######now its useless#########₹
#####№####№#####################


import random
def generate_id():
    return str(random.randint(100000000, 9999999999))